#include "RF24.h"
#include "platform.h"
#include <stdio.h>

/* =========================================================================
 *  Hardware abstraction  -- adjust these 4 macros + SPI_RW for your board
 * ========================================================================= */
#define RF24_CSN_PORT   GPIOA
#define RF24_CSN_PIN    GPIO_Pin_15
#define RF24_CE_PORT    GPIOA
#define RF24_CE_PIN     GPIO_Pin_2

#define CSN_HIGH()      GPIO_SetBits(RF24_CSN_PORT, RF24_CSN_PIN)
#define CSN_LOW()       GPIO_ResetBits(RF24_CSN_PORT, RF24_CSN_PIN)
#define CE_HIGH()       GPIO_SetBits(RF24_CE_PORT, RF24_CE_PIN)
#define CE_LOW()        GPIO_ResetBits(RF24_CE_PORT, RF24_CE_PIN)

/* =========================================================================
 *  Internal state
 * ========================================================================= */
static uint8_t  rf24_payload_size = 32;
static uint8_t  rf24_addr_width   = 5;
static uint8_t  rf24_pipe0_addr[5];
static uint8_t  rf24_pipe0_addr_set = 0;

/* =========================================================================
 *  Low-level SPI byte exchange
 * ========================================================================= */
static uint8_t spi_rw(uint8_t data)
{
    SPI_SendData(SPI1, data);
    while (RESET == SPI_GetFlagStatus(SPI1, SPI_FLAG_TXEPT)) { }
    while (RESET == SPI_GetFlagStatus(SPI1, SPI_FLAG_RXAVL)) { }
    return (uint8_t)SPI_ReceiveData(SPI1);
}

/* =========================================================================
 *  Register access primitives
 * ========================================================================= */
uint8_t RF24_read_register(uint8_t reg)
{
    uint8_t val;
    CSN_LOW();
    spi_rw(NRF_CMD_R_REGISTER | (reg & NRF_CMD_REGISTER_MASK));
    val = spi_rw(NRF_CMD_NOP);
    CSN_HIGH();
    return val;
}

void RF24_read_register_buf(uint8_t reg, uint8_t *buf, uint8_t len)
{
    uint8_t i;
    CSN_LOW();
    spi_rw(NRF_CMD_R_REGISTER | (reg & NRF_CMD_REGISTER_MASK));
    for (i = 0; i < len; i++) buf[i] = spi_rw(NRF_CMD_NOP);
    CSN_HIGH();
}

uint8_t RF24_write_register(uint8_t reg, uint8_t value)
{
    uint8_t status;
    CSN_LOW();
    status = spi_rw(NRF_CMD_W_REGISTER | (reg & NRF_CMD_REGISTER_MASK));
    spi_rw(value);
    CSN_HIGH();
    return status;
}

uint8_t RF24_write_register_buf(uint8_t reg, const uint8_t *buf, uint8_t len)
{
    uint8_t status, i;
    CSN_LOW();
    status = spi_rw(NRF_CMD_W_REGISTER | (reg & NRF_CMD_REGISTER_MASK));
    for (i = 0; i < len; i++) spi_rw(buf[i]);
    CSN_HIGH();
    return status;
}

/* =========================================================================
 *  Status / utility
 * ========================================================================= */
uint8_t RF24_getStatus(void)
{
    uint8_t s;
    CSN_LOW();
    s = spi_rw(NRF_CMD_NOP);
    CSN_HIGH();
    return s;
}

void RF24_flush_tx(void)
{
    CSN_LOW();
    spi_rw(NRF_CMD_FLUSH_TX);
    CSN_HIGH();
}

void RF24_flush_rx(void)
{
    CSN_LOW();
    spi_rw(NRF_CMD_FLUSH_RX);
    CSN_HIGH();
}

/* =========================================================================
 *  Configuration
 * ========================================================================= */
void RF24_setChannel(uint8_t ch)
{
    if (ch > 125) ch = 125;
    RF24_write_register(NRF_REG_RF_CH, ch);
}

uint8_t RF24_getChannel(void)
{
    return RF24_read_register(NRF_REG_RF_CH);
}

void RF24_setPayloadSize(uint8_t size)
{
    if (size > 32) size = 32;
    rf24_payload_size = size;
}

uint8_t RF24_getPayloadSize(void) { return rf24_payload_size; }

void RF24_setAddressWidth(uint8_t a_width)
{
    if (a_width < 3) a_width = 3;
    if (a_width > 5) a_width = 5;
    rf24_addr_width = a_width;
    RF24_write_register(NRF_REG_SETUP_AW, a_width - 2);
}

void RF24_setRetries(uint8_t delay, uint8_t count)
{
    RF24_write_register(NRF_REG_SETUP_RETR,
                        ((delay & 0x0F) << 4) | (count & 0x0F));
}

void RF24_setDataRate(rf24_datarate_e speed)
{
    uint8_t setup = RF24_read_register(NRF_REG_RF_SETUP);
    setup &= ~((1 << NRF_BIT_RF_DR_LOW) | (1 << NRF_BIT_RF_DR_HIGH));
    if (speed == RF24_250KBPS)      setup |= (1 << NRF_BIT_RF_DR_LOW);
    else if (speed == RF24_2MBPS)   setup |= (1 << NRF_BIT_RF_DR_HIGH);
    /* 1 Mbps -> both bits 0 */
    RF24_write_register(NRF_REG_RF_SETUP, setup);
}

rf24_datarate_e RF24_getDataRate(void)
{
    uint8_t s = RF24_read_register(NRF_REG_RF_SETUP);
    if (s & (1 << NRF_BIT_RF_DR_LOW))  return RF24_250KBPS;
    if (s & (1 << NRF_BIT_RF_DR_HIGH)) return RF24_2MBPS;
    return RF24_1MBPS;
}

void RF24_setPALevel(rf24_pa_dbm_e level)
{
    uint8_t setup = RF24_read_register(NRF_REG_RF_SETUP) & 0xF8;
    if (level > RF24_PA_MAX) level = RF24_PA_MAX;
    setup |= (level << 1) | 0x01;   /* RF_PWR bits + LNA bit (legacy) */
    RF24_write_register(NRF_REG_RF_SETUP, setup);
}

void RF24_setCRCLength(rf24_crclength_e length)
{
    uint8_t cfg = RF24_read_register(NRF_REG_CONFIG);
    cfg &= ~((1 << NRF_BIT_EN_CRC) | (1 << NRF_BIT_CRCO));
    if (length == RF24_CRC_8)       cfg |= (1 << NRF_BIT_EN_CRC);
    else if (length == RF24_CRC_16) cfg |= (1 << NRF_BIT_EN_CRC) | (1 << NRF_BIT_CRCO);
    RF24_write_register(NRF_REG_CONFIG, cfg);
}

void RF24_setAutoAck(uint8_t enable)
{
    RF24_write_register(NRF_REG_EN_AA, enable ? 0x3F : 0x00);
}

/* =========================================================================
 *  Power control
 * ========================================================================= */
void RF24_powerUp(void)
{
    uint8_t cfg = RF24_read_register(NRF_REG_CONFIG);
    if (!(cfg & (1 << NRF_BIT_PWR_UP)))
    {
        RF24_write_register(NRF_REG_CONFIG, cfg | (1 << NRF_BIT_PWR_UP));
        Delay_ms(5);   /* Tpd2stby */
    }
}

void RF24_powerDown(void)
{
    CE_LOW();
    uint8_t cfg = RF24_read_register(NRF_REG_CONFIG);
    RF24_write_register(NRF_REG_CONFIG, cfg & ~(1 << NRF_BIT_PWR_UP));
}

/* =========================================================================
 *  Pipes
 * ========================================================================= */
void RF24_openWritingPipe(const uint8_t *address)
{
    RF24_write_register_buf(NRF_REG_RX_ADDR_P0, address, rf24_addr_width);
    RF24_write_register_buf(NRF_REG_TX_ADDR,    address, rf24_addr_width);
    RF24_write_register(NRF_REG_RX_PW_P0, rf24_payload_size);
}

void RF24_openReadingPipe(uint8_t pipe, const uint8_t *address)
{
    if (pipe > 5) return;

    if (pipe == 0)
    {
        /* cache pipe-0 addr -- restored after stopListening */
        uint8_t i;
        for (i = 0; i < rf24_addr_width; i++) rf24_pipe0_addr[i] = address[i];
        rf24_pipe0_addr_set = 1;
    }

    if (pipe < 2)
        RF24_write_register_buf(NRF_REG_RX_ADDR_P0 + pipe, address, rf24_addr_width);
    else
        RF24_write_register(NRF_REG_RX_ADDR_P0 + pipe, address[0]);  /* only LSB differs */

    RF24_write_register(NRF_REG_RX_PW_P0 + pipe, rf24_payload_size);

    uint8_t en = RF24_read_register(NRF_REG_EN_RXADDR);
    RF24_write_register(NRF_REG_EN_RXADDR, en | (1 << pipe));
}

void RF24_closeReadingPipe(uint8_t pipe)
{
    if (pipe > 5) return;
    uint8_t en = RF24_read_register(NRF_REG_EN_RXADDR);
    RF24_write_register(NRF_REG_EN_RXADDR, en & ~(1 << pipe));
}

/* =========================================================================
 *  Listening
 * ========================================================================= */
void RF24_startListening(void)
{
    uint8_t cfg = RF24_read_register(NRF_REG_CONFIG);
    RF24_write_register(NRF_REG_CONFIG,
                        cfg | (1 << NRF_BIT_PWR_UP) | (1 << NRF_BIT_PRIM_RX));
    /* Clear flags */
    RF24_write_register(NRF_REG_STATUS,
                        (1 << NRF_BIT_RX_DR) | (1 << NRF_BIT_TX_DS) | (1 << NRF_BIT_MAX_RT));

    if (rf24_pipe0_addr_set)
        RF24_write_register_buf(NRF_REG_RX_ADDR_P0, rf24_pipe0_addr, rf24_addr_width);

    RF24_flush_rx();
    RF24_flush_tx();

    CE_HIGH();
    Delay_ms(1);    /* Tstby2a */
}

void RF24_stopListening(void)
{
    CE_LOW();
    Delay_ms(1);
    RF24_flush_tx();
    RF24_flush_rx();

    uint8_t cfg = RF24_read_register(NRF_REG_CONFIG);
    RF24_write_register(NRF_REG_CONFIG, cfg & ~(1 << NRF_BIT_PRIM_RX));
}

/* =========================================================================
 *  TX / RX
 * ========================================================================= */
uint8_t RF24_available(void)
{
    return RF24_availablePipe(0);
}

uint8_t RF24_availablePipe(uint8_t *pipe_num)
{
    uint8_t status = RF24_getStatus();
    uint8_t pipe   = (status >> NRF_BIT_RX_P_NO) & 0x07;

    if (pipe > 5) return 0;
    if (pipe_num) *pipe_num = pipe;
    return 1;
}

uint8_t RF24_write(const void *buf, uint8_t len)
{
    const uint8_t *p = (const uint8_t *)buf;
    uint8_t status, i;
    uint32_t timeout;

    /* Clear flags */
    RF24_write_register(NRF_REG_STATUS,
                        (1 << NRF_BIT_TX_DS) | (1 << NRF_BIT_MAX_RT));

    /* Load payload */
    CSN_LOW();
    spi_rw(NRF_CMD_W_TX_PAYLOAD);
    for (i = 0; i < len; i++) spi_rw(p[i]);
    /* Pad with zeros if static payload size > len */
    for (; i < rf24_payload_size; i++) spi_rw(0);
    CSN_HIGH();

    /* Pulse CE to start TX */
    CE_HIGH();
    Delay_ms(1);
    CE_LOW();

    /* Wait for TX_DS or MAX_RT */
    timeout = 100;   /* ~100 ms */
    while (timeout--)
    {
        status = RF24_getStatus();
        if (status & ((1 << NRF_BIT_TX_DS) | (1 << NRF_BIT_MAX_RT))) break;
        Delay_ms(1);
    }

    /* Clear flags */
    RF24_write_register(NRF_REG_STATUS,
                        (1 << NRF_BIT_TX_DS) | (1 << NRF_BIT_MAX_RT));

    if (status & (1 << NRF_BIT_MAX_RT))
    {
        RF24_flush_tx();
        return 0;   /* failed */
    }
    return (status & (1 << NRF_BIT_TX_DS)) ? 1 : 0;
}

void RF24_read(void *buf, uint8_t len)
{
    uint8_t *p = (uint8_t *)buf;
    uint8_t i;

    CSN_LOW();
    spi_rw(NRF_CMD_R_RX_PAYLOAD);
    for (i = 0; i < len; i++) p[i] = spi_rw(NRF_CMD_NOP);
    CSN_HIGH();

    RF24_write_register(NRF_REG_STATUS, (1 << NRF_BIT_RX_DR));
}

/* =========================================================================
 *  whatHappened
 * ========================================================================= */
void RF24_whatHappened(uint8_t *tx_ok, uint8_t *tx_fail, uint8_t *rx_ready)
{
    uint8_t status = RF24_write_register(NRF_REG_STATUS,
                       (1 << NRF_BIT_RX_DR) | (1 << NRF_BIT_TX_DS) | (1 << NRF_BIT_MAX_RT));
    if (tx_ok)    *tx_ok    = (status >> NRF_BIT_TX_DS) & 1;
    if (tx_fail)  *tx_fail  = (status >> NRF_BIT_MAX_RT) & 1;
    if (rx_ready) *rx_ready = (status >> NRF_BIT_RX_DR) & 1;
}

/* =========================================================================
 *  Connectivity check  (RF24::isChipConnected)
 *  Writes-then-reads SETUP_AW to verify SPI link is alive.
 * ========================================================================= */
uint8_t RF24_isChipConnected(void)
{
    uint8_t aw = RF24_read_register(NRF_REG_SETUP_AW);
    return (aw >= 1 && aw <= 3);
}

/* =========================================================================
 *  begin()  -- equivalent to RF24::begin()
 * ========================================================================= */
uint8_t RF24_begin(void)
{
    CE_LOW();
    CSN_HIGH();
    Delay_ms(100);                  /* power-on settle */

    /* Sensible defaults (match RF24 lib) */
    RF24_write_register(NRF_REG_CONFIG, 0x0C);          /* CRC16, PWR off */
    RF24_setRetries(5, 15);                             /* 1500us, 15 retries */
    RF24_setPALevel(RF24_PA_MAX);
    RF24_setDataRate(RF24_1MBPS);
    RF24_setCRCLength(RF24_CRC_16);
    RF24_write_register(NRF_REG_DYNPD, 0x00);           /* no dynamic payload */
    RF24_write_register(NRF_REG_FEATURE, 0x00);
    RF24_write_register(NRF_REG_STATUS,
        (1 << NRF_BIT_RX_DR) | (1 << NRF_BIT_TX_DS) | (1 << NRF_BIT_MAX_RT));
    RF24_setChannel(76);
    RF24_flush_rx();
    RF24_flush_tx();

    RF24_powerUp();

    /* PRIM_RX = 0 (TX standby) */
    uint8_t cfg = RF24_read_register(NRF_REG_CONFIG);
    RF24_write_register(NRF_REG_CONFIG, cfg & ~(1 << NRF_BIT_PRIM_RX));

    return RF24_isChipConnected();
}

/* =========================================================================
 *  printDetails  (RF24::printDetails)
 * ========================================================================= */
static void print_addr_reg(const char *name, uint8_t reg, uint8_t qty)
{
    uint8_t buf[5];
    uint8_t i, j;
    printf("%-12s =", name);
    while (qty--)
    {
        RF24_read_register_buf(reg++, buf, rf24_addr_width);
        printf(" 0x");
        for (i = 0, j = rf24_addr_width; j > 0; j--, i++)
            printf("%02X", buf[j - 1]);
    }
    printf("\r\n");
}

static void print_byte_reg(const char *name, uint8_t reg, uint8_t qty)
{
    printf("%-12s =", name);
    while (qty--) printf(" 0x%02X", RF24_read_register(reg++));
    printf("\r\n");
}

void RF24_printDetails(void)
{
    static const char *dr_str[] = { "1 Mbps", "2 Mbps", "250 Kbps" };
    static const char *pa_str[] = { "PA_MIN", "PA_LOW", "PA_HIGH", "PA_MAX" };
    uint8_t setup, cfg;

    printf("\r\n================ RF24 ================\r\n");
    print_byte_reg("STATUS",      NRF_REG_STATUS,      1);
    print_addr_reg("RX_ADDR_P0-1",NRF_REG_RX_ADDR_P0,  2);
    print_byte_reg("RX_ADDR_P2-5",NRF_REG_RX_ADDR_P2,  4);
    print_addr_reg("TX_ADDR",     NRF_REG_TX_ADDR,     1);
    print_byte_reg("RX_PW_P0-5",  NRF_REG_RX_PW_P0,    6);
    print_byte_reg("EN_AA",       NRF_REG_EN_AA,       1);
    print_byte_reg("EN_RXADDR",   NRF_REG_EN_RXADDR,   1);
    print_byte_reg("RF_CH",       NRF_REG_RF_CH,       1);
    print_byte_reg("RF_SETUP",    NRF_REG_RF_SETUP,    1);
    print_byte_reg("CONFIG",      NRF_REG_CONFIG,      1);
    print_byte_reg("DYNPD/FEATURE", NRF_REG_DYNPD,     2);

    setup = RF24_read_register(NRF_REG_RF_SETUP);
    cfg   = RF24_read_register(NRF_REG_CONFIG);

    printf("Data Rate    = %s\r\n", dr_str[RF24_getDataRate()]);
    printf("Model        = nRF24L01%s\r\n", "+");
    printf("CRC Length   = %d bits\r\n",
           (cfg & (1 << NRF_BIT_EN_CRC)) ? ((cfg & (1 << NRF_BIT_CRCO)) ? 16 : 8) : 0);
    printf("PA Power     = %s\r\n", pa_str[(setup >> 1) & 0x03]);
    printf("Channel      = %d  (%.3f GHz)\r\n",
           RF24_getChannel(), 2.400f + RF24_getChannel() / 1000.0f);
    printf("Chip Conn.   = %s\r\n", RF24_isChipConnected() ? "OK" : "FAIL");
    printf("======================================\r\n");
}