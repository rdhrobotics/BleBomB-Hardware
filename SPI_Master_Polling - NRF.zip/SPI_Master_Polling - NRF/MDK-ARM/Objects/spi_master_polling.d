./objects/spi_master_polling.o: ..\spi_master_polling.c
