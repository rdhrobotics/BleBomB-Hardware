/*
    Lightweight RF24 driver for MM32 (polling SPI).
    Inspired by https://github.com/nRF24/RF24
*/
#ifndef RF24_H_
#define RF24_H_

#include <stdint.h>
#include "nRF24L01.h"

/* ---- Data rate enumeration (matches RF24 lib) ---- */
typedef enum {
    RF24_1MBPS  = 0,
    RF24_2MBPS  = 1,
    RF24_250KBPS = 2
} rf24_datarate_e;

/* ---- PA level enumeration ---- */
typedef enum {
    RF24_PA_MIN  = 0,   /* -18 dBm */
    RF24_PA_LOW  = 1,   /* -12 dBm */
    RF24_PA_HIGH = 2,   /*  -6 dBm */
    RF24_PA_MAX  = 3    /*   0 dBm */
} rf24_pa_dbm_e;

/* ---- CRC length ---- */
typedef enum {
    RF24_CRC_DISABLED = 0,
    RF24_CRC_8        = 1,
    RF24_CRC_16       = 2
} rf24_crclength_e;

/* =========================================================================
 *  Public API  (mirrors RF24::xxx methods from the Arduino library)
 * ========================================================================= */

/* Init / chip control */
uint8_t  RF24_begin(void);
void     RF24_powerUp(void);
void     RF24_powerDown(void);
uint8_t  RF24_isChipConnected(void);

/* Configuration */
void     RF24_setChannel(uint8_t channel);
uint8_t  RF24_getChannel(void);
void     RF24_setPayloadSize(uint8_t size);
uint8_t  RF24_getPayloadSize(void);
void     RF24_setDataRate(rf24_datarate_e speed);
rf24_datarate_e RF24_getDataRate(void);
void     RF24_setPALevel(rf24_pa_dbm_e level);
void     RF24_setCRCLength(rf24_crclength_e length);
void     RF24_setAutoAck(uint8_t enable);
void     RF24_setRetries(uint8_t delay, uint8_t count);
void     RF24_setAddressWidth(uint8_t a_width);

/* Pipes */
void     RF24_openWritingPipe(const uint8_t *address);
void     RF24_openReadingPipe(uint8_t pipe, const uint8_t *address);
void     RF24_closeReadingPipe(uint8_t pipe);

/* Listening */
void     RF24_startListening(void);
void     RF24_stopListening(void);

/* TX / RX */
uint8_t  RF24_available(void);
uint8_t  RF24_availablePipe(uint8_t *pipe_num);
uint8_t  RF24_write(const void *buf, uint8_t len);
void     RF24_read(void *buf, uint8_t len);
void     RF24_flush_tx(void);
void     RF24_flush_rx(void);

/* Status */
uint8_t  RF24_getStatus(void);
void     RF24_whatHappened(uint8_t *tx_ok, uint8_t *tx_fail, uint8_t *rx_ready);

/* Debug */
void     RF24_printDetails(void);

/* Low level (exposed for advanced use) */
uint8_t  RF24_read_register(uint8_t reg);
void     RF24_read_register_buf(uint8_t reg, uint8_t *buf, uint8_t len);
uint8_t  RF24_write_register(uint8_t reg, uint8_t value);
uint8_t  RF24_write_register_buf(uint8_t reg, const uint8_t *buf, uint8_t len);

#endif /* RF24_H_ */