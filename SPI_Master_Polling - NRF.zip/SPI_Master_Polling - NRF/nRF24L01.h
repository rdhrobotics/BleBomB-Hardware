/*
    nRF24L01 / nRF24L01+ register and command definitions.
    C-compatible port of the original Stefan Engelke / RF24 header.
*/
#ifndef NRF24L01_H_
#define NRF24L01_H_

/* Memory Map */
#define NRF_REG_CONFIG        0x00
#define NRF_REG_EN_AA         0x01
#define NRF_REG_EN_RXADDR     0x02
#define NRF_REG_SETUP_AW      0x03
#define NRF_REG_SETUP_RETR    0x04
#define NRF_REG_RF_CH         0x05
#define NRF_REG_RF_SETUP      0x06
#define NRF_REG_STATUS        0x07
#define NRF_REG_OBSERVE_TX    0x08
#define NRF_REG_CD            0x09
#define NRF_REG_RPD           0x09
#define NRF_REG_RX_ADDR_P0    0x0A
#define NRF_REG_RX_ADDR_P1    0x0B
#define NRF_REG_RX_ADDR_P2    0x0C
#define NRF_REG_RX_ADDR_P3    0x0D
#define NRF_REG_RX_ADDR_P4    0x0E
#define NRF_REG_RX_ADDR_P5    0x0F
#define NRF_REG_TX_ADDR       0x10
#define NRF_REG_RX_PW_P0      0x11
#define NRF_REG_RX_PW_P1      0x12
#define NRF_REG_RX_PW_P2      0x13
#define NRF_REG_RX_PW_P3      0x14
#define NRF_REG_RX_PW_P4      0x15
#define NRF_REG_RX_PW_P5      0x16
#define NRF_REG_FIFO_STATUS   0x17
#define NRF_REG_DYNPD         0x1C
#define NRF_REG_FEATURE       0x1D

/* CONFIG */
#define NRF_BIT_MASK_RX_DR    6
#define NRF_BIT_MASK_TX_DS    5
#define NRF_BIT_MASK_MAX_RT   4
#define NRF_BIT_EN_CRC        3
#define NRF_BIT_CRCO          2
#define NRF_BIT_PWR_UP        1
#define NRF_BIT_PRIM_RX       0

/* STATUS */
#define NRF_BIT_RX_DR         6
#define NRF_BIT_TX_DS         5
#define NRF_BIT_MAX_RT        4
#define NRF_BIT_RX_P_NO       1
#define NRF_BIT_TX_FULL       0

/* FIFO_STATUS */
#define NRF_BIT_TX_REUSE      6
#define NRF_BIT_FIFO_FULL     5
#define NRF_BIT_TX_EMPTY      4
#define NRF_BIT_RX_FULL       1
#define NRF_BIT_RX_EMPTY      0

/* RF_SETUP */
#define NRF_BIT_CONT_WAVE     7
#define NRF_BIT_RF_DR_LOW     5
#define NRF_BIT_PLL_LOCK      4
#define NRF_BIT_RF_DR_HIGH    3
#define NRF_BIT_RF_PWR        1   /* 2 bits at [2:1] */

/* FEATURE */
#define NRF_BIT_EN_DPL        2
#define NRF_BIT_EN_ACK_PAY    1
#define NRF_BIT_EN_DYN_ACK    0

/* SPI Commands */
#define NRF_CMD_R_REGISTER          0x00
#define NRF_CMD_W_REGISTER          0x20
#define NRF_CMD_REGISTER_MASK       0x1F
#define NRF_CMD_ACTIVATE            0x50
#define NRF_CMD_R_RX_PL_WID         0x60
#define NRF_CMD_R_RX_PAYLOAD        0x61
#define NRF_CMD_W_TX_PAYLOAD        0xA0
#define NRF_CMD_W_ACK_PAYLOAD       0xA8
#define NRF_CMD_W_TX_PAYLOAD_NO_ACK 0xB0
#define NRF_CMD_FLUSH_TX            0xE1
#define NRF_CMD_FLUSH_RX            0xE2
#define NRF_CMD_REUSE_TX_PL         0xE3
#define NRF_CMD_NOP                 0xFF

#endif /* NRF24L01_H_ */