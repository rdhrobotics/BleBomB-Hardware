/*
 * 2.4 GHz Jammer � MM32 Port  (FINAL FIX)
 * ==========================================
 *
 * ROOT CAUSE ANALYSIS vs Arduino original
 * ----------------------------------------
 *
 * The Arduino sketch does this:
 *   setup()  ? radio.startConstCarrier(RF24_PA_MAX, 45)   // ONCE, CE goes HIGH, stays HIGH
 *   loop()   ? AttackAll() just calls radio.setChannel(i)  // only RF_CH changes, CE never toggled
 *
 * Previous MM32 ports called NRF_StartConstCarrier() inside AttackAll() on
 * every main-loop iteration, which pulls CE LOW then HIGH each sweep.
 * Even the "fixed" version toggled CE at the start of each sweep.
 *
 * CORRECT BEHAVIOR:
 *   1. Call NRF_StartConstCarrier() ONCE after init ? CE stays HIGH forever
 *      (or until mode change).
 *   2. AttackAll / AttackWifi ONLY call RF24_setChannel() � nothing else.
 *   3. On mode change: CE goes LOW, mode switches, CE goes HIGH again on
 *      the new mode's first channel, or stays LOW for IDLE.
 *
 * Full list of fixes
 * ------------------
 * FIX-1  CE_HIGH/CE_LOW macro collision with RF24.c ? renamed JAMMER_CE_*
 * FIX-2  AttackAll/AttackWifi no longer call NRF_StartConstCarrier() on
 *        every sweep. Carrier is armed ONCE; sweeps only call setChannel().
 * FIX-3  NRF_StartConstCarrier uses read-modify-write on RF_SETUP so PA
 *        level bits set by RF24_setPALevel() are not discarded.
 * FIX-4  RF24_setCRCLength(RF24_CRC_DISABLED) is the LAST config call so
 *        it cannot be overwritten by earlier read-modify-writes to CONFIG.
 * FIX-5  NRF_StopConstCarrier uses read-modify-write, preserving PA bits.
 * FIX-6  g_carrier_on flag guards against re-arming an already-active
 *        carrier (prevents spurious CE glitches on repeated loop entries).
 *
 * Pin mapping
 * -----------
 *  SPI1  SCK  ? PA8
 *        MOSI ? PA9
 *        MISO ? PA10
 *  NRF   CSN  ? PA15
 *        CE   ? PA2
 *  WS2812     ? PA0   (single LED)
 *  Button     ? PB1   (LOW = pressed, internal pull-up)
 *
 * Modes (button cycles):
 *   IDLE  ? GREEN  � carrier parked on ch 76, no hopping
 *   ALL   ? RED    � sweep ch 0�124 continuously
 *   WIFI  ? ORANGE � sweep Wi-Fi ch 1�11 only
 */

#define _MAIN_C_

#include <stdio.h>
#include "platform.h"
#include "spi_master_polling.h"
#include "main.h"
#include "RF24.h"

/* -- Pin aliases -- */
#define WS_PIN      GPIO_Pin_0   /* PA0  WS2812 data */
#define BUTTON_PIN  GPIO_Pin_1   /* PB1  active LOW  */

/*
 * CE is PA2. RF24.c defines its own CE_HIGH/CE_LOW internally.
 * We use a distinct name here to avoid macro redefinition. (FIX-1)
 */
#define JAMMER_CE_HIGH()  GPIO_SetBits(GPIOA,   GPIO_Pin_2)
#define JAMMER_CE_LOW()   GPIO_ResetBits(GPIOA, GPIO_Pin_2)

/* nRF24L01+ RF_SETUP register address */
#define NRF_RF_SETUP   0x06u
/* Continuous-carrier bits (nRF24L01+ PS �6.4) */
#define CONT_WAVE      (1u << 7)   /* RF_SETUP[7] */
#define PLL_LOCK       (1u << 4)   /* RF_SETUP[4] */

/*
 * Wi-Fi 2.4 GHz channels � centre freq (MHz) minus 2400 = nRF channel.
 * ch1=2412?12 � ch11=2462?62
 * Matches: wifiFrequencies[i] - 2400  in the Arduino sketch.
 */
static const uint8_t wifi_channels[] = {
    12, 17, 22, 27, 32, 37, 42, 47, 52, 57, 62
};
#define WIFI_CH_COUNT  ((uint8_t)(sizeof(wifi_channels)/sizeof(wifi_channels[0])))

/* Starting channel used in Arduino sketch: byte i = 45 */
#define INIT_CHANNEL   45u

/* -- Attack mode -- */
typedef enum {
    MODE_IDLE = 0,   /* GREEN  � carrier parked, no sweep */
    MODE_ALL  = 1,   /* RED    � sweep ch 0-124           */
    MODE_WIFI = 2    /* ORANGE � sweep Wi-Fi ch 1-11      */
} AttackMode;

static AttackMode g_mode       = MODE_IDLE;
static uint8_t    g_carrier_on = 0;   /* FIX-6: tracks whether CE is HIGH */

/* -----------------------------------------------------------
 *  WS2812 bit-bang (single LED, PA0)
 * ----------------------------------------------------------- */

static void WS2812_Init(void)
{
    GPIO_InitTypeDef g;
    RCC_AHBPeriphClockCmd(RCC_AHBPERIPH_GPIOA, ENABLE);
    GPIO_StructInit(&g);
    g.GPIO_Pin   = WS_PIN;
    g.GPIO_Mode  = GPIO_Mode_Out_PP;
    g.GPIO_Speed = GPIO_Speed_High;
    GPIO_Init(GPIOA, &g);
    GPIO_ResetBits(GPIOA, WS_PIN);
}

static void WS2812_SendBit(uint8_t bit)
{
    if (bit) {
        GPIO_SetBits(GPIOA, WS_PIN);
        __NOP(); __NOP(); __NOP(); __NOP(); __NOP();   /* ~700 ns HIGH */
        GPIO_ResetBits(GPIOA, WS_PIN);
        __NOP(); __NOP();                              /* ~600 ns LOW  */
    } else {
        GPIO_SetBits(GPIOA, WS_PIN);
        __NOP(); __NOP();                              /* ~350 ns HIGH */
        GPIO_ResetBits(GPIOA, WS_PIN);
        __NOP(); __NOP(); __NOP(); __NOP(); __NOP();   /* ~800 ns LOW  */
    }
}

static void WS2812_SendByte(uint8_t byte)
{
    int i;
    for (i = 7; i >= 0; i--)
        WS2812_SendBit((byte >> i) & 0x01u);
}

/* WS2812 wire order: G ? R ? B */
static void WS2812_SetColor(uint8_t r, uint8_t g, uint8_t b)
{
    __disable_irq();
    WS2812_SendByte(g);
    WS2812_SendByte(r);
    WS2812_SendByte(b);
    __enable_irq();
    Delay_ms(1);   /* > 50 �s reset latch */
}

static void LED_Red(void)    { WS2812_SetColor(255,   0,  0); }
static void LED_Green(void)  { WS2812_SetColor(  0, 255,  0); }
static void LED_Orange(void) { WS2812_SetColor(255,  80,  0); }
static void LED_Off(void)    { WS2812_SetColor(  0,   0,  0); }

/* -----------------------------------------------------------
 *  Button � PB1, internal pull-up, LOW = pressed
 * ----------------------------------------------------------- */

static void Button_Init(void)
{
    GPIO_InitTypeDef g;
    RCC_AHBPeriphClockCmd(RCC_AHBPERIPH_GPIOB, ENABLE);
    GPIO_StructInit(&g);
    g.GPIO_Pin   = BUTTON_PIN;
    g.GPIO_Mode  = GPIO_Mode_IPU;   /* internal pull-up */
    g.GPIO_Speed = GPIO_Speed_High;
    GPIO_Init(GPIOB, &g);
}

static uint8_t Button_IsPressed(void)
{
    return (GPIO_ReadInputDataBit(GPIOB, BUTTON_PIN) == 0) ? 1u : 0u;
}

/* -----------------------------------------------------------
 *  SPI / board hardware init
 * ----------------------------------------------------------- */

static void Free_JTAG_Pins(void)
{
#ifdef GPIO_Remap_SWJ_JTAGDisable
    RCC_APB1PeriphClockCmd(RCC_APB1PERIPH_AFIO, ENABLE);
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
#endif
}

static void Board_SPI_Init(void)
{
    GPIO_InitTypeDef g;
    SPI_InitTypeDef  s;

    RCC_AHBPeriphClockCmd(RCC_AHBPERIPH_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1PERIPH_SPI1, ENABLE);
    Free_JTAG_Pins();

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource8,  GPIO_AF_0);  /* SCK  */
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9,  GPIO_AF_0);  /* MOSI */
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_0);  /* MISO */

    /* SCK + MOSI � AF push-pull */
    GPIO_StructInit(&g);
    g.GPIO_Pin   = GPIO_Pin_8 | GPIO_Pin_9;
    g.GPIO_Speed = GPIO_Speed_High;
    g.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &g);

    /* MISO � floating input */
    GPIO_StructInit(&g);
    g.GPIO_Pin   = GPIO_Pin_10;
    g.GPIO_Speed = GPIO_Speed_High;
    g.GPIO_Mode  = GPIO_Mode_FLOATING;
    GPIO_Init(GPIOA, &g);

    /* CSN (PA15) + CE (PA2) � push-pull outputs */
    GPIO_StructInit(&g);
    g.GPIO_Pin   = GPIO_Pin_15 | GPIO_Pin_2;
    g.GPIO_Speed = GPIO_Speed_High;
    g.GPIO_Mode  = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &g);

    GPIO_SetBits(GPIOA,   GPIO_Pin_15);  /* CSN idle HIGH */
    GPIO_ResetBits(GPIOA, GPIO_Pin_2);   /* CE  idle LOW  */

    /* SPI Mode 0, MSB first, ~1 MHz */
    SPI_StructInit(&s);
    s.SPI_Mode              = SPI_Mode_Master;
    s.SPI_DataSize          = SPI_DataSize_8b;
    s.SPI_DataWidth         = 8;
    s.SPI_CPOL              = SPI_CPOL_Low;
    s.SPI_CPHA              = SPI_CPHA_1Edge;
    s.SPI_NSS               = SPI_NSS_Soft;
    s.SPI_BaudRatePrescaler = SPI_BaudratePrescaler_64;
    s.SPI_FirstBit          = SPI_FirstBit_MSB;
    SPI_Init(SPI1, &s);

    SPI_BiDirectionalLineConfig(SPI1, SPI_Enable_RX);
    SPI_BiDirectionalLineConfig(SPI1, SPI_Enable_TX);
    SPI_Cmd(SPI1, ENABLE);
}

/* -----------------------------------------------------------
 *  Continuous-carrier control
 *
 *  nRF24L01+ datasheet �6.4:
 *    Write CONT_WAVE=1 and PLL_LOCK=1 into RF_SETUP, then
 *    assert CE HIGH.  The chip transmits an unmodulated
 *    carrier on the programmed channel for as long as CE
 *    stays HIGH.
 *
 *  Channel hopping DURING carrier:
 *    Write a new value to RF_CH only. CE stays HIGH.
 *    The PLL re-acquires lock on the new frequency.
 *    No CE toggling is needed or wanted between hops.
 *
 *  This is exactly what the Arduino RF24 library does:
 *    startConstCarrier() sets bits + CE HIGH once.
 *    AttackAll/wifiAttack then only call setChannel().
 * ----------------------------------------------------------- */

/*
 * NRF_StartConstCarrier
 * Arms the continuous-carrier mode on 'channel' and raises CE.
 * FIX-3: read-modify-write preserves PA level and data-rate bits.
 * FIX-6: does nothing if carrier already active (no spurious glitch).
 */
static void NRF_StartConstCarrier(uint8_t channel)
{
    uint8_t rf_setup;

    if (g_carrier_on) return;   /* FIX-6: already on, don't re-arm */

    JAMMER_CE_LOW();
    Delay_ms(1);

    RF24_setChannel(channel);

    /* FIX-3: read first, then set only the carrier bits */
    rf_setup  = RF24_read_register(NRF_RF_SETUP);
    rf_setup |= CONT_WAVE | PLL_LOCK;
    RF24_write_register(NRF_RF_SETUP, rf_setup);

    JAMMER_CE_HIGH();   /* carrier begins � CE stays HIGH */
    Delay_ms(1);        /* Tstby2a: chip needs =130 �s to enter TX */

    g_carrier_on = 1;
}

/*
 * NRF_StopConstCarrier
 * Stops the carrier: pulls CE LOW, clears CONT_WAVE + PLL_LOCK.
 * FIX-5: read-modify-write preserves PA level and data-rate bits.
 */
static void NRF_StopConstCarrier(void)
{
    uint8_t rf_setup;

    if (!g_carrier_on) return;  /* already off */

    JAMMER_CE_LOW();
    Delay_ms(1);

    rf_setup  = RF24_read_register(NRF_RF_SETUP);
    rf_setup &= ~(CONT_WAVE | PLL_LOCK);
    RF24_write_register(NRF_RF_SETUP, rf_setup);

    g_carrier_on = 0;
}

/* -----------------------------------------------------------
 *  Attack sweep functions
 *
 *  FIX-2 (ROOT CAUSE):
 *  The carrier is armed ONCE (in main before the loop or on
 *  mode switch). The sweep functions ONLY call RF24_setChannel().
 *  CE is never toggled inside a sweep � it stays HIGH throughout.
 *
 *  This exactly mirrors the Arduino sketch:
 *    setup()  ? startConstCarrier(RF24_PA_MAX, 45)
 *    loop()   ? AttackAll() just calls radio.setChannel(i)
 * ----------------------------------------------------------- */

static void AttackAll(void)
{
    uint8_t ch;
    /*
     * Carrier must already be ON (armed in mode-switch code).
     * We only change the channel � CE stays HIGH the whole time.
     */
    for (ch = 0; ch < 125; ch++) {
        RF24_setChannel(ch);
        /* No Delay_ms here � sweep as fast as possible, same as Arduino */
    }
}

static void AttackWifi(void)
{
    uint8_t i;
    for (i = 0; i < WIFI_CH_COUNT; i++) {
        RF24_setChannel(wifi_channels[i]);
        /* No forced delay � tight sweep mirrors Arduino behavior */
    }
}

/* -----------------------------------------------------------
 *  Apply mode: stop carrier, switch LED, re-arm carrier
 * ----------------------------------------------------------- */

static void ApplyMode(AttackMode mode)
{
    NRF_StopConstCarrier();   /* CE LOW, clear CW bits */

    g_mode = mode;

    switch (mode) {
        case MODE_ALL:
            printf("Mode -> ALL 2.4 GHz (RED)\r\n");
            LED_Red();
            /* Arm carrier on ch 0; sweep will hop from there */
            NRF_StartConstCarrier(0);
            break;

        case MODE_WIFI:
            printf("Mode -> Wi-Fi only (ORANGE)\r\n");
            LED_Orange();
            /* Arm carrier on first Wi-Fi channel */
            NRF_StartConstCarrier(wifi_channels[0]);
            break;

        case MODE_IDLE:
        default:
            printf("Mode -> IDLE (GREEN)\r\n");
            LED_Green();
            /* Park carrier on channel 76 � no sweep */
            NRF_StartConstCarrier(76);
            break;
    }
}

/* -----------------------------------------------------------
 *  main
 * ----------------------------------------------------------- */

int main(void)
{
    uint8_t btn_prev = 0;
    uint8_t btn_curr = 0;

    InitDelay();
    Serial_begin(115200);
    printf("\r\n=== 2.4 GHz Jammer  MM32 ===\r\n");

    Board_SPI_Init();
    WS2812_Init();
    Button_Init();

    /* -- NRF24 init -- */
    if (!RF24_begin()) {
        printf("RF24_begin() FAILED  check SPI/power wiring!\r\n");
        while (1) {
            LED_Red(); Delay_ms(150);
            LED_Off(); Delay_ms(150);
        }
    }
    printf("RF24 chip OK\r\n");

    /*
     * Jammer configuration � exact mirror of Arduino setup():
     *   radio.setAutoAck(false)
     *   radio.stopListening()
     *   radio.setRetries(0, 0)
     *   radio.setPayloadSize(5)
     *   radio.setAddressWidth(3)
     *   radio.setPALevel(RF24_PA_MAX)
     *   radio.setDataRate(RF24_2MBPS)
     *   radio.setCRCLength(RF24_CRC_DISABLED)   ? FIX-4: must be last
     */
    RF24_setAutoAck(0);
    RF24_stopListening();
    RF24_setRetries(0, 0);
    RF24_setPayloadSize(5);
    RF24_setAddressWidth(3);
    RF24_setPALevel(RF24_PA_MAX);
    RF24_setDataRate(RF24_2MBPS);
    RF24_setCRCLength(RF24_CRC_DISABLED);   /* FIX-4: always last */

    RF24_printDetails();

    /*
     * Arduino sketch starts in IDLE equivalent:
     *   radio.startConstCarrier(RF24_PA_MAX, 45)  ? channel 45
     * then enters advertising loop before attack.
     * We start directly in IDLE with carrier parked on ch 45.
     */
    ApplyMode(MODE_IDLE);   /* GREEN, carrier on ch 76 */
    /* Override to ch 45 to exactly match Arduino starting channel */
    RF24_setChannel(INIT_CHANNEL);

    printf("IDLE (GREEN)  press button to cycle modes\r\n");
    printf("  Press 1x -> ALL 2.4 GHz (RED)\r\n");
    printf("  Press 2x -> Wi-Fi only  (ORANGE)\r\n");
    printf("  Press 3x -> IDLE        (GREEN)\r\n");

    /* -- Main loop -- */
    while (1)
    {
        /* Debounced falling-edge detection (line goes LOW = pressed) */
        btn_curr = Button_IsPressed();

        if (btn_curr && !btn_prev) {
            Delay_ms(20);                       /* debounce */
            if (Button_IsPressed()) {
                /* Cycle: IDLE(0) -> ALL(1) -> WIFI(2) -> IDLE(0) */
                AttackMode next = (AttackMode)((g_mode + 1) % 3);
                ApplyMode(next);
                /* Wait for release */
                while (Button_IsPressed()) Delay_ms(5);
            }
        }
        btn_prev = btn_curr;

        /* -- Execute current attack -- */
        switch (g_mode) {
            case MODE_ALL:
                /*
                 * Carrier already active (CE HIGH from ApplyMode).
                 * Just sweep channel register � no CE toggling. (FIX-2)
                 */
                AttackAll();
                break;

            case MODE_WIFI:
                AttackWifi();
                break;

            case MODE_IDLE:
            default:
                /*
                 * Carrier parked on ch 45/76.
                 * Nothing to do � button polling handles everything.
                 */
                Delay_ms(5);
                break;
        }
    }
}