#define _MAIN_C_

#include <stdio.h>
#include "platform.h"
#include "spi_master_polling.h"
#include "main.h"
#include "RF24.h"

/* ====================== Hardware init ====================== */
static void Free_JTAG_Pins(void)
{
#ifdef GPIO_Remap_SWJ_JTAGDisable
    RCC_APB1PeriphClockCmd(RCC_APB1PERIPH_AFIO, ENABLE);
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
#endif
}

static void Board_SPI_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    SPI_InitTypeDef  SPI_InitStruct;

    RCC_AHBPeriphClockCmd(RCC_AHBPERIPH_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1PERIPH_SPI1, ENABLE);

    Free_JTAG_Pins();

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource8,  GPIO_AF_0);  /* SCK  */
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9,  GPIO_AF_0);  /* MOSI */
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_0);  /* MISO */

    /* SCK + MOSI : AF push-pull */
    GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.GPIO_Pin   = GPIO_Pin_8 | GPIO_Pin_9;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_High;
    GPIO_InitStruct.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* MISO : floating input */
    GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.GPIO_Pin   = GPIO_Pin_10;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_High;
    GPIO_InitStruct.GPIO_Mode  = GPIO_Mode_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* CSN(PA15) + CE(PA2) : push-pull outputs */
    GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.GPIO_Pin   = GPIO_Pin_15 | GPIO_Pin_2;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_High;
    GPIO_InitStruct.GPIO_Mode  = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_SetBits(GPIOA, GPIO_Pin_15);    /* CSN idle high */
    GPIO_ResetBits(GPIOA, GPIO_Pin_2);   /* CE  idle low  */

    /* SPI Mode 0, MSB first, ~1 MHz */
    SPI_StructInit(&SPI_InitStruct);
    SPI_InitStruct.SPI_Mode              = SPI_Mode_Master;
    SPI_InitStruct.SPI_DataSize          = SPI_DataSize_8b;
    SPI_InitStruct.SPI_DataWidth         = 8;
    SPI_InitStruct.SPI_CPOL              = SPI_CPOL_Low;
    SPI_InitStruct.SPI_CPHA              = SPI_CPHA_1Edge;
    SPI_InitStruct.SPI_NSS               = SPI_NSS_Soft;
    SPI_InitStruct.SPI_BaudRatePrescaler = SPI_BaudratePrescaler_64;
    SPI_InitStruct.SPI_FirstBit          = SPI_FirstBit_MSB;
    SPI_Init(SPI1, &SPI_InitStruct);

    SPI_BiDirectionalLineConfig(SPI1, SPI_Enable_RX);
    SPI_BiDirectionalLineConfig(SPI1, SPI_Enable_TX);

    SPI_Cmd(SPI1, ENABLE);
}

/* ====================== Application ====================== */
static const uint8_t pipe_addr[5] = { 0xE7, 0xE7, 0xE7, 0xE7, 0xE7 };

int main(void)
{
    uint8_t  payload[32];
    uint8_t  i, ok;
    uint32_t tx_count = 0;

    InitDelay();
    Serial_begin(115200);
   // PLATFORM_PrintInfo();

    printf("\r\n=== RF24 Lightweight Library Demo ===\r\n");

    Board_SPI_Init();

    if (!RF24_begin())
    {
        printf("\r\n*** RF24_begin() FAILED -- check wiring/power ***\r\n");
        while (1) { Delay_ms(1000); }
    }

    /* Configure as transmitter */
    RF24_setPayloadSize(32);
    RF24_setChannel(76);
    RF24_setDataRate(RF24_1MBPS);
    RF24_setPALevel(RF24_PA_MAX);
    RF24_setCRCLength(RF24_CRC_16);
    RF24_setAutoAck(1);
    RF24_setRetries(5, 15);
    RF24_openWritingPipe(pipe_addr);
    RF24_openReadingPipe(1, pipe_addr);
    RF24_stopListening();

    RF24_printDetails();

    /* Build initial payload */
    for (i = 0; i < 32; i++) payload[i] = i;

    while (1)
    {
        payload[0] = (uint8_t)(tx_count & 0xFF);
        payload[1] = (uint8_t)((tx_count >> 8) & 0xFF);

        ok = RF24_write(payload, 32);
        printf("TX #%lu : %s   (STATUS=0x%02X)\r\n",
               (unsigned long)tx_count,
               ok ? "OK" : "FAIL",
               RF24_getStatus());

        tx_count++;
        Delay_ms(1000);
    }
}